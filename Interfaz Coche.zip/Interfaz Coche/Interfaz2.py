#####################IMPORTS#######################
import socket
import os
import time
import threading
import time
import PySimpleGUI as sg
import pickle
import traceback
from PySimpleGUI.PySimpleGUI import Titlebar, Window
import json
#####################VARIABLES#######################
velocidad=0.0
angulo=0.0
deadman=False
velocidad_max=0.0
estado='Parado'


imgVelocidad="velocidad_PARADO.png"
imgVolante = "volante.png"
imgSemaforo = "semaforo_rojo.png"



ip="localhost"
Port=5050
BUFFER_SIZE=1024

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((ip, Port))
server.listen(1)
#####################GUI#######################

layout = [[sg.Image("logoiteam.png",size=(512,170),background_color="white")],


[sg.Image("coche_rees.png",size=(512,304),background_color="white")],

[sg.Text("V: " + str(round(velocidad,2))+"Km/h " + '\n' + "VMax = " + '\n' + estado + str(velocidad_max)+" Km/h",text_color="black",key="velocidadInterfaz", background_color="white"), sg.Image(imgVelocidad,size=(152,147),key="imgVelInterfaz",background_color="white"), sg.Image(imgSemaforo,size=(110,110),key="imgSemaforo",background_color="white"), sg.Image("volante.png",size=(217,217),key="imgVolante",background_color="white"),  sg.Text("          ",background_color="white")]

]
############################################

def get_datos():
    cli, addr =server.accept()
    data = cli.recv(1024)
    fiveg_data= json.loads(data.decode("utf-8"))
    cli.close()
    velocidad=fiveg_data.get("speed")
    angulo=fiveg_data.get("angle")
    deadman=fiveg_data.get("deadman")
    velocidad_max=fiveg_data.get("maxSpeed")
    print(velocidad,angulo,deadman,velocidad_max)
    return velocidad, angulo, deadman, velocidad_max


def img_volante (angulo):
    if angulo==90:
        imgVolante="volante.png"
        
    elif angulo>80 and angulo < 90:
        imgVolante="volante10I.png"
        
    elif angulo>70 and angulo <= 80:
        imgVolante="volante20I.png"

    elif angulo>60 and angulo <= 70:
        imgVolante="volante30I.png"

    elif angulo>50 and angulo <= 60:
        imgVolante="volante40I.png"

    elif angulo>40 and angulo <= 50:
        imgVolante="volante50I.png"

    elif angulo>30 and angulo <= 40:
        imgVolante="volante60I.png"

    elif angulo>20 and angulo <= 30:
        imgVolante="volante70I.png"

    elif angulo>10 and angulo <= 20:
        imgVolante="volante80I.png"

    elif angulo>=0 and angulo <= 10:
        imgVolante="volante90I.png"

    elif angulo>90 and angulo <= 100:
        imgVolante="volante10D.png"

    elif angulo>100 and angulo <= 110:
        imgVolante="volante20D.png"

    elif angulo>110 and angulo <= 120:
        imgVolante="volante30D.png"

    elif angulo>120 and angulo <= 130:
        imgVolante="volante40D.png"

    elif angulo>130 and angulo <= 140:
        imgVolante="volante50D.png"

    elif angulo>140 and angulo <= 150:
        imgVolante="volante60D.png"

    elif angulo>150 and angulo <= 160:
        imgVolante="volante70D.png"

    elif angulo>160 and angulo <= 170:
        imgVolante="volante80D.png"

    elif angulo>170 and angulo <= 180:
        imgVolante="volante90D.png"

    else: 
        imgVolante = "volante.png"    
    return imgVolante

def img_velocidad (velocidad, velocidad_max):
    if velocidad==0:
        imgVelocidad="velocidad_Parado.png"

    elif velocidad>0 and velocidad <= velocidad_max/7:
        imgVelocidad="velocidad_1.png"

    elif velocidad>velocidad_max/7 and velocidad <= 2*velocidad_max/7:
        imgVelocidad="velocidad_2.png"

    elif velocidad>2*velocidad_max/7 and velocidad <= 3*velocidad_max/7:
        imgVelocidad="velocidad_3.png"

    elif velocidad>3*velocidad_max/7 and velocidad <= 4*velocidad_max/7:
        imgVelocidad="velocidad_4.png"

    elif velocidad>4*velocidad_max/7 and velocidad <= 5*velocidad_max/7:
        imgVelocidad="velocidad_5.png"

    elif velocidad>5*velocidad_max/7 and velocidad <= 6*velocidad_max/7:
        imgVelocidad="velocidad_6.png"

    elif velocidad>6*velocidad_max/7:
        imgVelocidad="velocidad_MAX.png"

    else: 
        imgVelocidad = "velocidad_Parado.png"    
    return imgVelocidad

def img_semaforo (deadman):
    if deadman == True:
        imgSemaforo = "semaforo_verde.png"

    else: 
        imgSemaforo = "semaforo_rojo.png"
    return imgSemaforo

#def angulo_ajuste (angulo):
    if angulo == 90:
        angulo = 0
        #return angulo
    elif angulo<90 and angulo>=0:
        angulo=90-angulo
        #return angulo
    elif angulo>90 and angulo<=180:
        angulo=angulo-90
    return angulo
    

def velocidad_ajuste(velocidad):
    if velocidad<77:
        estado='Atras'
    elif velocidad>77:
        estado='Adelante'
    elif velocidad==77:
        estado='Parado'
    velocidad=abs(velocidad-77)
    return velocidad, estado


# Create the window
window = sg.Window("5G RobotCar", layout,size=(900,700),element_justification='c',background_color="white")

while True:
    event, values = window.read(timeout=1)
    window.Refresh()
    velocidad,angulo,deadman,velocidad_max=get_datos()
    velocidad, estado=velocidad_ajuste(velocidad)
    imgVelocidad=img_velocidad(velocidad,velocidad_max)
    imgSemaforo=img_semaforo(deadman)
    imgVolante = img_volante(angulo)
    window['velocidadInterfaz'].Update("V: " + str(round(velocidad,2))+"Km/h " + '\n' + "VMax = " + str(velocidad_max)+" Km/h"+ '\n' + estado )
    window['imgVelInterfaz'].Update(imgVelocidad)
    window['imgSemaforo'].Update(imgSemaforo)
    window['imgVolante'].Update(imgVolante)

    if event == sg.WIN_CLOSED:
        break
window.close()